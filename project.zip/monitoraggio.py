import streamlit as st
import datetime
import pandas as pd

def calcola_dosi_disponibili(farmaco):
    """
    Calcola il numero di dosi disponibili per un farmaco.
    """
    return farmaco["num_confezioni"] * farmaco["pezzi_per_confezione"] - farmaco["dosi_consumate"]

def calcola_consumo_giornaliero(farmaco):
    """
    Calcola il consumo giornaliero di un farmaco in base al programma.
    """
    giorni_settimana = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"]
    giorni_di_assunzione = [giorno in farmaco["giorni"] for giorno in giorni_settimana]
    numero_giorni_assunzione = sum(giorni_di_assunzione)
    
    if numero_giorni_assunzione == 0:
        return 0
    
    return (farmaco["dose"] * len(farmaco["orari"]) * numero_giorni_assunzione) / 7

def calcola_giorni_rimanenti(farmaco):
    """
    Calcola il numero di giorni rimanenti per cui si ha scorta sufficiente.
    """
    dosi_disponibili = calcola_dosi_disponibili(farmaco)
    consumo_giornaliero = calcola_consumo_giornaliero(farmaco)
    
    if consumo_giornaliero <= 0:
        return float('inf')  # Nessun consumo, quindi scorta infinita
        
    return dosi_disponibili / consumo_giornaliero

def verifica_scorte_tutti(farmaci):
    """
    Verifica le scorte di tutti i farmaci e mostra avvisi per quelli
    con scorte insufficienti.
    """
    if not farmaci:
        st.info("Non hai ancora aggiunto farmaci. Vai alla scheda 'Aggiungi Farmaco' per iniziare.")
        return
    
    # Prepara dati per la tabella
    data = []
    
    for farmaco in farmaci:
        dosi_disponibili = calcola_dosi_disponibili(farmaco)
        consumo_giornaliero = calcola_consumo_giornaliero(farmaco)
        giorni_rimanenti = calcola_giorni_rimanenti(farmaco)
        
        stato = "✅ Sufficiente"
        
        if giorni_rimanenti < 3:
            stato = "⚠️ Scorte basse! < 3 giorni"
        elif giorni_rimanenti < 7:
            stato = "⚠️ Da acquistare presto"
        
        data.append({
            "Farmaco": farmaco["nome"],
            "Dosi disponibili": f"{dosi_disponibili:.1f}",
            "Consumo giornaliero": f"{consumo_giornaliero:.2f}",
            "Giorni rimanenti": f"{giorni_rimanenti:.1f}",
            "Stato": stato
        })
    
    # Visualizza la tabella
    df = pd.DataFrame(data)
    st.dataframe(df)
    
    # Evidenzia i farmaci con scorte basse
    farmaci_critici = [f for f in farmaci if calcola_giorni_rimanenti(f) < 3]
    
    if farmaci_critici:
        st.warning("⚠️ I seguenti farmaci hanno scorte sufficienti per meno di 3 giorni:")
        for farmaco in farmaci_critici:
            giorni = calcola_giorni_rimanenti(farmaco)
            st.markdown(f"- **{farmaco['nome']}**: {giorni:.1f} giorni rimanenti")

def aggiorna_consumo(farmaci):
    """
    Aggiorna il conteggio delle dosi consumate per il giorno corrente.
    """
    oggi = datetime.datetime.now().strftime("%Y-%m-%d")
    ultimo_aggiornamento = st.session_state.get('ultimo_aggiornamento', None)
    
    # Se già aggiornato oggi, non procedere
    if ultimo_aggiornamento == oggi:
        return
    
    # Ottieni il giorno della settimana corrente in italiano
    giorni_settimana = ["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"]
    giorno_attuale = giorni_settimana[datetime.datetime.now().weekday()]
    
    # Aggiorna il consumo per ogni farmaco da assumere oggi
    for farmaco in farmaci:
        if giorno_attuale in farmaco["giorni"]:
            # Calcola il numero di dosi da assumere oggi
            dosi_oggi = farmaco["dose"] * len(farmaco["orari"])
            farmaco["dosi_consumate"] += dosi_oggi
    
    # Aggiorna la data dell'ultimo aggiornamento
    st.session_state['ultimo_aggiornamento'] = oggi
