import json
import os
import streamlit as st

# Percorso del file per salvare i dati
FARMACI_FILE = "farmaci.json"

def salva_farmaci(farmaci):
    """
    Salva la lista dei farmaci su file JSON.
    """
    try:
        with open(FARMACI_FILE, "w", encoding="utf-8") as file:
            json.dump(farmaci, file, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        st.error(f"Errore durante il salvataggio dei farmaci: {e}")
        return False

def carica_farmaci():
    """
    Carica la lista dei farmaci dal file JSON.
    Ritorna una lista vuota se il file non esiste o in caso di errore.
    """
    if not os.path.exists(FARMACI_FILE):
        return []
    
    try:
        with open(FARMACI_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except Exception as e:
        st.error(f"Errore durante il caricamento dei farmaci: {e}")
        return []
