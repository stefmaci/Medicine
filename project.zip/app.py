import streamlit as st
import pandas as pd
import datetime
from gestione_farmaci import (
    visualizza_farmaci, 
    aggiungi_farmaco_ui,
    visualizza_programma_settimanale,
    rimuovi_farmaco
)
from monitoraggio import verifica_scorte_tutti, aggiorna_consumo
from persistence import carica_farmaci, salva_farmaci

# Configurazione della pagina
st.set_page_config(
    page_title="Promemoria Farmaci",
    page_icon="💊",
    layout="wide"
)

# Inizializzazione dello stato della sessione
if 'farmaci' not in st.session_state:
    st.session_state.farmaci = carica_farmaci()
    aggiorna_consumo(st.session_state.farmaci)

# Titolo dell'applicazione
st.title("💊 Promemoria Farmaci")

# Creazione delle schede
tab1, tab2, tab3, tab4 = st.tabs([
    "Farmaci", 
    "Aggiungi Farmaco", 
    "Programma Settimanale", 
    "Monitoraggio Scorte"
])

# Scheda 1: Visualizzazione e gestione dei farmaci
with tab1:
    st.header("I tuoi Farmaci")
    
    farmaci_aggiornati = visualizza_farmaci(st.session_state.farmaci)
    if farmaci_aggiornati != st.session_state.farmaci:
        st.session_state.farmaci = farmaci_aggiornati
        salva_farmaci(st.session_state.farmaci)
        st.rerun()
    
    if st.button("Aggiorna Consumo", key="aggiorna_consumo_btn"):
        aggiorna_consumo(st.session_state.farmaci)
        salva_farmaci(st.session_state.farmaci)
        st.success("Consumo aggiornato al giorno corrente!")
        st.rerun()

# Scheda 2: Aggiunta di un nuovo farmaco
with tab2:
    st.header("Aggiungi un Nuovo Farmaco")
    
    if aggiungi_farmaco_ui():
        salva_farmaci(st.session_state.farmaci)
        st.success("Farmaco aggiunto con successo!")
        st.rerun()

# Scheda 3: Visualizzazione del programma settimanale
with tab3:
    st.header("Programma Settimanale")
    visualizza_programma_settimanale(st.session_state.farmaci)

# Scheda 4: Monitoraggio delle scorte
with tab4:
    st.header("Monitoraggio Scorte")
    verifica_scorte_tutti(st.session_state.farmaci)

# Footer
st.markdown("---")
st.markdown("#### 📝 Promemoria Farmaci - Un'app per gestire l'assunzione dei tuoi farmaci")
