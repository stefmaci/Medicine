import streamlit as st
import pandas as pd
from datetime import datetime
import json

# Giorni della settimana in italiano
GIORNI_SETTIMANA = [
    "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"
]

def aggiungi_farmaco_ui():
    """
    Interfaccia utente per aggiungere un nuovo farmaco.
    Ritorna True se il farmaco è stato aggiunto, False altrimenti.
    """
    with st.form("form_aggiungi_farmaco"):
        nome = st.text_input("Nome del farmaco")
        
        # Selezione multipla per i giorni della settimana
        giorni = st.multiselect(
            "Giorni della settimana",
            options=GIORNI_SETTIMANA
        )
        
        # Input per gli orari (separati da virgola)
        orari_input = st.text_input(
            "Orari (separati da virgola, es. 08:00,20:00)",
            placeholder="08:00,15:00,20:00"
        )
        
        dose = st.number_input(
            "Dose (numero di pillole per assunzione)",
            min_value=0.25,
            value=1.0,
            step=0.25
        )
        
        pezzi_per_confezione = st.number_input(
            "Numero di pezzi per confezione",
            min_value=1,
            value=10,
            step=1
        )
        
        num_confezioni = st.number_input(
            "Numero di confezioni in possesso",
            min_value=0.0,
            value=1.0,
            step=0.5
        )
        
        invia = st.form_submit_button("Aggiungi Farmaco")
        
        if invia:
            # Validazione dei dati
            if not nome:
                st.error("Il nome del farmaco è obbligatorio.")
                return False
                
            if not giorni:
                st.error("Seleziona almeno un giorno della settimana.")
                return False
                
            if not orari_input:
                st.error("Inserisci almeno un orario.")
                return False
            
            # Elaborazione degli orari inseriti
            orari = [orario.strip() for orario in orari_input.split(",")]
            
            # Validazione del formato orario
            for orario in orari:
                try:
                    datetime.strptime(orario, "%H:%M")
                except ValueError:
                    st.error(f"Formato orario non valido: {orario}. Usa il formato HH:MM.")
                    return False
            
            # Creazione del nuovo farmaco
            nuovo_farmaco = {
                "nome": nome.strip(),
                "giorni": giorni,
                "orari": orari,
                "dose": float(dose),
                "pezzi_per_confezione": int(pezzi_per_confezione),
                "num_confezioni": float(num_confezioni),
                "dosi_consumate": 0
            }
            
            # Aggiunta del farmaco alla lista
            if 'farmaci' not in st.session_state:
                st.session_state.farmaci = []
                
            st.session_state.farmaci.append(nuovo_farmaco)
            return True
    
    return False

def visualizza_farmaci(farmaci):
    """
    Visualizza la lista dei farmaci in una tabella e consente di modificarli.
    Ritorna la lista aggiornata dei farmaci.
    """
    if not farmaci:
        st.info("Non hai ancora aggiunto farmaci. Vai alla scheda 'Aggiungi Farmaco' per iniziare.")
        return farmaci
    
    farmaci_aggiornati = farmaci.copy()
    
    for i, farmaco in enumerate(farmaci):
        with st.expander(f"{farmaco['nome']}"):
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"**Giorni di assunzione:** {', '.join(farmaco['giorni'])}")
                st.write(f"**Orari:** {', '.join(farmaco['orari'])}")
                st.write(f"**Dose per assunzione:** {farmaco['dose']}")
                
                # Calcolo dosi totali e residue
                dosi_totali = farmaco['num_confezioni'] * farmaco['pezzi_per_confezione']
                dosi_residue = dosi_totali - farmaco['dosi_consumate']
                
                st.write(f"**Pezzi per confezione:** {farmaco['pezzi_per_confezione']}")
                
                # Modifica numero confezioni
                num_conf = st.number_input(
                    "Numero di confezioni",
                    min_value=0.0,
                    value=float(farmaco['num_confezioni']),
                    step=0.5,
                    key=f"conf_{i}"
                )
                if num_conf != farmaco['num_confezioni']:
                    farmaci_aggiornati[i]['num_confezioni'] = num_conf
                
                st.write(f"**Dosi consumate:** {farmaco['dosi_consumate']}")
                st.write(f"**Dosi residue:** {dosi_residue}")
            
            with col2:
                if st.button("Rimuovi", key=f"rm_{i}"):
                    if rimuovi_farmaco(i):
                        st.success(f"Farmaco '{farmaco['nome']}' rimosso con successo!")
                        st.rerun()
    
    return farmaci_aggiornati

def rimuovi_farmaco(indice):
    """
    Rimuove un farmaco dalla lista dei farmaci.
    """
    if 'farmaci' in st.session_state and 0 <= indice < len(st.session_state.farmaci):
        st.session_state.farmaci.pop(indice)
        return True
    return False

def visualizza_programma_settimanale(farmaci):
    """
    Visualizza il programma settimanale in una tabella organizzata per giorno e orario.
    """
    if not farmaci:
        st.info("Non hai ancora aggiunto farmaci. Vai alla scheda 'Aggiungi Farmaco' per iniziare.")
        return
    
    # Creazione del calendario settimanale
    calendario = {}
    for giorno in GIORNI_SETTIMANA:
        calendario[giorno] = {}
    
    # Popolamento del calendario
    for farmaco in farmaci:
        for giorno in farmaco["giorni"]:
            for orario in farmaco["orari"]:
                if orario not in calendario[giorno]:
                    calendario[giorno][orario] = []
                calendario[giorno][orario].append({
                    "nome": farmaco["nome"],
                    "dose": farmaco["dose"]
                })
    
    # Visualizzazione del calendario
    for giorno in GIORNI_SETTIMANA:
        st.subheader(giorno)
        
        if not calendario[giorno]:
            st.write("Nessun farmaco programmato per questo giorno.")
            continue
        
        # Ordina le medicine per orario
        orari_ordinati = sorted(calendario[giorno].keys())
        
        # Creazione della tabella
        data = []
        for orario in orari_ordinati:
            for farmaco in calendario[giorno][orario]:
                data.append({
                    "Orario": orario,
                    "Farmaco": farmaco["nome"],
                    "Dose": farmaco["dose"]
                })
        
        if data:
            df = pd.DataFrame(data)
            st.table(df)
        else:
            st.write("Nessun farmaco programmato per questo giorno.")
